import argparse
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from jev_compare import core
from jev_compare.api import LiveClient, classify, normalize, evaluate_with_retry
from jev_compare.cli import execute
from jev_compare.report import safe_csv

def answer(impact='changed', sufficient='sufficient', category='behavior'):
    return {k: {'choice': v, 'confidence': 0.99} for k,v in
            [('impact',impact),('sufficiency',sufficient),('category',category)]}

class Fake:
    def __init__(self, config): self.attempts = 0
    def evaluate(self, state):
        self.attempts += 1
        return answer()
    def close(self): pass

class ComparisonTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.old, self.new = self.root/'old', self.root/'new'
        self.old.mkdir(); self.new.mkdir()
        self.skill = self.root/'SKILL.md'
        self.skill.write_text('PRINT n outputs integer n', encoding='utf-8')
        self.config = core.load_config()
        self.specs = core.load_specs([self.skill], self.config)

    def files(self, a, b, name='file.xxx'):
        if a is not None: (self.old/name).write_bytes(a)
        if b is not None: (self.new/name).write_bytes(b)

    def plan(self): return core.plan(self.old, self.new, self.config, self.specs)

    def args(self, send=False, limit=10):
        return argparse.Namespace(old=str(self.old),new=str(self.new),skill=[str(self.skill)],
            output=str(self.root/'out'),config=None,send=send,max_items=limit)

    def report(self):
        return json.loads(next((self.root/'out').glob('*/report.json')).read_text())

    def test_unchanged(self):
        self.files(b'PRINT 1\n',b'PRINT 1\n')
        self.assertEqual(self.plan()['unchanged_files'],1)
        self.assertFalse(self.plan()['items'])

    def test_changed(self):
        self.files(b'PRINT 1\n',b'PRINT 2\n')
        item=self.plan()['items'][0]
        self.assertEqual(item['state']['new_code'],'PRINT 2\n')
        self.assertEqual(item['old_range'],[1,1])

    def test_add_delete(self):
        self.files(None,b'PRINT 2\n','a.xxx'); self.files(b'PRINT 1\n',None,'d.xxx')
        self.assertEqual({i['change'] for i in self.plan()['items']},{'added','deleted'})

    def test_empty_added(self):
        self.files(None,b'')
        self.assertEqual(self.plan()['items'][0]['reason'],'existence_or_encoding_only')

    def test_newlines_not_normalized(self):
        self.files(b'PRINT 1\r\n',b'PRINT 1\n')
        self.assertEqual(len(self.plan()['items']),1)

    def test_decode_error(self):
        self.files(b'\xff',b'a')
        self.assertEqual(self.plan()['items'][0]['reason'],'decode_error')

    def test_cp932(self):
        self.config['encoding']='cp932'
        self.files('旧'.encode('cp932'),'新'.encode('cp932'))
        self.assertEqual(self.plan()['items'][0]['state']['new_code'],'新')

    def test_binary(self):
        self.files(b'\0a',b'\0b')
        self.assertEqual(self.plan()['items'][0]['reason'],'binary_or_nul')

    def test_size_guard(self):
        self.config['max_file_bytes']=1
        self.files(b'ab',b'cd')
        self.assertEqual(self.plan()['items'][0]['reason'],'file_too_large')

    def test_payload_guard(self):
        self.config['max_payload_chars']=1
        self.files(b'a',b'b')
        self.assertEqual(self.plan()['items'][0]['reason'],'payload_too_large')

    def test_line_guard(self):
        self.config['max_file_lines']=1
        self.files(b'a\nb\n',b'c\nd\n')
        self.assertEqual(self.plan()['items'][0]['reason'],'too_many_lines')

    def test_excluded_inventory(self):
        self.files(b'a',b'b','secret.txt')
        self.assertEqual(len(self.plan()['excluded']),2)
        self.assertFalse(self.plan()['items'])

    def test_symlink_not_followed(self):
        try: (self.old/'link.xxx').symlink_to(self.skill)
        except OSError: self.skipTest('symlink unavailable')
        self.assertEqual(self.plan()['items'][0]['reason'],'link_not_followed')

    def test_paths(self):
        with self.assertRaises(ValueError):
            core.validate_paths(self.old,self.old,self.root/'out',[self.skill])
        with self.assertRaises(ValueError):
            core.validate_paths(self.old,self.new,self.old/'out',[self.skill])

    def test_config_validation(self):
        p=self.root/'bad.json'; p.write_text('{"extensions": []}')
        with self.assertRaises(ValueError): core.load_config(p)
        p.write_text('{"context_lines": true}')
        with self.assertRaises(ValueError): core.load_config(p)

    def test_full_specs(self):
        second=self.root/'extra.md'; second.write_text('Extra semantics')
        docs=core.load_specs([self.skill,second],self.config)
        self.assertEqual(len(docs),2)

    def test_multi_chunk_coverage(self):
        self.config['context_lines']=2
        a=[f'PRINT {i}\n' for i in range(100)]
        b=list(a); b[2]='PRINT 999\n'; b[90]='PRINT 888\n'
        self.files(''.join(a).encode(),''.join(b).encode())
        items=self.plan()['items']
        self.assertEqual(len(items),2)
        ranges=[r['new'] for i in items for r in i['state']['changed_ranges']]
        self.assertEqual(ranges,[[3,3],[91,91]])

    def test_no_network_dryrun(self):
        self.files(b'a',b'b')
        def prohibited(config): raise AssertionError('Network factory called')
        self.assertEqual(execute(self.args(),prohibited),0)
        self.assertEqual(self.report()['items'][0]['reason'],'dry_run_no_network')

    def test_mock_live_and_max_items(self):
        self.files(b'a',b'b'); self.files(b'a',b'c','other.xxx')
        self.assertEqual(execute(self.args(True,1),Fake),2)
        report=self.report()
        self.assertEqual(report['items'][0]['bucket'],'HIGH')
        self.assertEqual(report['items'][1]['reason'],'max_items_limit')
        self.assertEqual(report['metadata']['api_attempts'],1)

    def test_setup_failure_retains_plan(self):
        self.files(b'a',b'b')
        def fail(c): raise ValueError('SECRET-NOT-LOGGED')
        self.assertEqual(execute(self.args(True),fail),2)
        self.assertNotIn('SECRET-NOT-LOGGED',json.dumps(self.report()))

    def test_auth_stops(self):
        self.files(b'a',b'b'); self.files(b'a',b'c','other.xxx')
        class Auth(Fake):
            def evaluate(self,state):
                self.attempts+=1
                e=RuntimeError('secret'); e.status=401; raise e
        self.assertEqual(execute(self.args(True),Auth),2)
        self.assertEqual(self.report()['items'][1]['reason'],'auth_stop')

    def test_interrupt_saved(self):
        self.files(b'a',b'b')
        class Interrupted(Fake):
            def evaluate(self,state): raise KeyboardInterrupt
        self.assertEqual(execute(self.args(True),Interrupted),130)
        self.assertEqual(self.report()['items'][0]['reason'],'interrupted_request_outcome_unknown')

    def test_input_immutable(self):
        self.files(b'a\r\n',b'b\n')
        before=[p.read_bytes() for p in (self.old/'file.xxx',self.new/'file.xxx')]
        execute(self.args(True),Fake)
        self.assertEqual(before,[p.read_bytes() for p in (self.old/'file.xxx',self.new/'file.xxx')])

    def test_eof_insertion(self):
        self.files(b'A\n',b'A\nB\n')
        changed=self.plan()['items'][0]['state']['changed_ranges'][0]
        self.assertEqual(changed,{'old':[2,1],'new':[2,2]})

    def test_html_escaping(self):
        self.files(b'A',b'<script>alert(1)</script>')
        execute(self.args(),Fake)
        text=next((self.root/'out').glob('*/report.html')).read_text()
        self.assertNotIn('<script>',text)
        self.assertIn('&lt;script&gt;',text)

    def test_spec_limit_and_empty(self):
        self.config['max_spec_bytes']=1
        with self.assertRaises(ValueError): core.load_specs([self.skill],self.config)
        self.skill.write_text('')
        with self.assertRaises(ValueError): core.load_specs([self.skill],self.config)

class PolicyTests(unittest.TestCase):
    def test_no_low(self):
        self.assertEqual(classify(answer('same','sufficient','cosmetic'))[0],'REVIEW')
        self.assertEqual(classify(answer())[0],'HIGH')
        self.assertEqual(classify(answer('changed','unknown'))[0],'REVIEW')
        self.assertEqual(classify(answer('same','sufficient','behavior'))[1],'inconsistent_answers')

    def test_csv_injection(self):
        for value in ['=1+1','  @foo','\tcmd','-3','+cmd']:
            self.assertTrue(safe_csv(value).startswith("'"))

    def test_response_validation(self):
        choices={k:SimpleNamespace(**v) for k,v in answer().items()}
        self.assertEqual(normalize(SimpleNamespace(choices=choices))['impact']['confidence'],0.99)
        choices['impact'].confidence=float('nan')
        self.assertIsNone(normalize(SimpleNamespace(choices=choices))['impact']['confidence'])
        choices['impact'].choice='invalid'
        with self.assertRaises(ValueError): normalize(SimpleNamespace(choices=choices))

    def test_retry_limit(self):
        class Busy(Fake):
            def evaluate(self,state):
                self.attempts+=1
                e=RuntimeError('DO NOT LOG'); e.status=429; raise e
        c=Busy({}); waits=[]
        result,error,fatal=evaluate_with_retry(c,{},2,waits.append)
        self.assertEqual(c.attempts,3)
        self.assertEqual(waits,[1,2])
        self.assertEqual(error,'http_429')
        self.assertFalse(fatal)

    def test_live_adapter_contract_offline(self):
        import types
        calls=[]
        class StubClient:
            def __init__(self,**kw): calls.append(kw)
            def system_one(self,**kw):
                calls.append(kw)
                return SimpleNamespace(choices={k:SimpleNamespace(**v) for k,v in answer().items()})
            def close(self): calls.append('closed')
        stub=types.ModuleType('typesafe_sdk')
        stub.TypeSafeClient=StubClient
        stub.Choice=lambda **kw:kw
        stub.RetryPolicy=lambda **kw:kw
        with patch.dict('sys.modules',{'typesafe_sdk':stub}), patch.dict('os.environ',{
                'TYPESAFE_API_KEY':'FAKE-TEST-KEY', 'TYPESAFE_BASE_URL':'https://api.typesafe.ai'}):
            client=LiveClient(core.load_config())
            self.assertEqual(client.evaluate({'sample':1})['impact']['choice'],'changed')
            client.close()
        self.assertEqual(calls[0]['retry'],{'max_retries':0})
        self.assertEqual(set(calls[1]['questions']),{'impact','sufficiency','category'})
        self.assertEqual(calls[-1],'closed')

    def test_custom_endpoint_rejected(self):
        with patch.dict('os.environ',{'TYPESAFE_API_KEY':'FAKE', 'TYPESAFE_BASE_URL':'https://example.org'}):
            with self.assertRaises(ValueError): LiveClient(core.load_config())

if __name__ == '__main__': unittest.main()
