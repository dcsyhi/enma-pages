# Jev Source Compare 1.0 — 独自言語の一括差分スクリーニング

Claude Code / Codex / ChatGPT / Claude の契約もAPIも不要です。
Python 3.12以上を推奨。ローカル前処理は標準ライブラリのみ。
API送信時だけ TypeSafe Python SDK と Jev APIキーが必要です。

## 最初に

ZIPをすべて展開し、このREADMEのあるフォルダでPowerShellを開きます。
最短手順は START_HERE.html にも記載しています。
このパッケージは実装済みのv1です。以前のHTML仕様にあった設計上の機能すべてを実装したものではありません。

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
.\.venv\Scripts\python.exe compare.py --old examples/old --new examples/new --skill examples/SKILL.md --config config.json --dry-run
```

ドライランとテストにはAPIキー・SDK・ネット接続は不要。
results配下の新しい実行フォルダ内のreport.htmlをブラウザで開いてください。
架空サンプルは4件の変更・1件の無変更を含みます。結果のpendingは正常で、まだAI判定していない意味です。

## 実APIを試す

TypeSafeアカウント、API利用権、料金、送信データの許可を先に確認します。
インストールは公式パッケージ配布先から行います。

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m pip freeze | Out-File -Encoding utf8 requirements.lock.txt
$jevSecret = Read-Host "TypeSafe API key" -AsSecureString
$env:TYPESAFE_API_KEY = [System.Net.NetworkCredential]::new("", $jevSecret).Password
Remove-Variable jevSecret
.\.venv\Scripts\python.exe compare.py --old examples/old --new examples/new --skill examples/SKILL.md --config config.json --send --max-items 4
Remove-Item Env:\TYPESAFE_API_KEY
```

必ず架空データから。実データのキー、コード、仕様を他者に共有しないでください。
requirements.txtは0.7.xに制限していますが、実際に取得した版をlockファイルに記録してください。
APIの有効なモデル名・上限は提供元で確認してください。

## 実際の独自言語に適用

1. config.jsonのextensionsを実際の拡張子へ変更（例 `.abc`, `.inc`）。
2. encodingを確認。UTF-8なら `utf-8`、WindowsのCP932なら `cp932`。自動推測しません。
3. 運用中のソースを直接操作せず、新旧の読取り用スナップショットを別フォルダへ用意。
4. SKILL.mdに参照先があるなら、その必要資料も `--skill` を繰返して明示指定。仕様資料はUTF-8。
5. 新旧で言語仕様が違う場合は、それぞれの適用版を仕様内に明記。
6. dry-runで全件と送信範囲を確認した後、少数だけsend。

```powershell
.\.venv\Scripts\python.exe compare.py --old "C:\work\old" --new "C:\work\new" --skill "C:\spec\SKILL.md" --skill "C:\spec\instructions.md" --config config.json --output "C:\work\reports" --dry-run
.\.venv\Scripts\python.exe compare.py --old "C:\work\old" --new "C:\work\new" --skill "C:\spec\SKILL.md" --skill "C:\spec\instructions.md" --config config.json --output "C:\work\reports" --send --max-items 10
```

--sendは外部送信の明示許可。指定なしは常にオフライン。
新旧フォルダ同士の重複・入れ子、出力先との重複は拒否します。
入力は読取りのみですが、比較中に別プロセスで変更しないでください。

## 判定の見方

- HIGH: 仕様・文脈が十分との回答があり、挙動変更が示唆された。重要度や不具合の確定ではありません。
- REVIEW: 不明、仕様不足、矛盾、エラー、未処理、または等価性を人手検証すべき変更。
- LOW: v1では無効です。same/cosmeticの回答もREVIEWへ残します。

つまりv1は「確認順の優先付け」が主目的です。自動除外はしません。
impact= sameの件数やconfidenceは評価材料であり、正答率の保証ではありません。
バグ修正の意図はコードだけで断定せず、bugfixの自動分類はしません。
不明な構文を一般言語の知識で推定しないよう質問しますが、誤判断を完全には防げません。

## 出力

実行ごとにresults/日時-IDを新規作成し、前の結果を上書きしません。

| ファイル | 内容 |
|---|---|
| report.html | 人間向け。各差分と送信stateを展開表示 |
| report.csv | UTF-8 BOM付き。Excel向け、数式注入対策あり |
| report.json | 仕様本文・新旧の抜粋・差分・ハッシュ・回答・実行条件 |
| summary.md | 状態別件数、無変更・除外数 |
| progress.jsonl | 実API処理開始と完了を逐次記録 |

JSON/HTMLにはコードや仕様が含まれます。アクセス制限・保管期限は利用者が管理してください。
元の全文は保存せず、全ファイルハッシュと送信した抜粋を保存します。元スナップショットも保管してください。
行範囲は1始まり・両端含む。空の範囲は開始 > 終了。diffヘッダは抜粋内相対行番号です。
old_range/new_rangeとchanged_rangesが元ファイルの行番号です。

status: pending=未送信、blocked=入力制限等、evaluated=応答取得、error=失敗。
件数制限で残ったものはpending/max_items_limit。レポートから消えません。
除外したディレクトリの中身は走査しないため、excludedのディレクトリ1件はファイル1件とは限りません。

## 中断と失敗

送信前に全件計画を保存し、各件完了後report.jsonを更新します。Ctrl+C時もレポートを作ります。
OS強制終了ではHTML/CSVが古いことがあります。report.jsonとprogress.jsonlを突き合わせてください。
リクエスト中に切断したものはサーバーで課金済みの可能性があるため、再送は慎重に。
自動再開・キャッシュ再利用はv1未搭載。再実行は先頭から再送し、追加課金され得ます。
必要に応じて対象スナップショットを小分けし、依存情報不足はREVIEWとして扱ってください。

終了コード: 0=ドライラン成功または送信対象処理完了、1=入力検証エラー、
2=blocked/error/pendingまたはセットアップ失敗が残る、130=Ctrl+C。
0は「すべて安全」ではありません。除外一覧とREVIEWは常に確認。

401/403で後続の送信を止めます。429/500/502/503/504は上限付き再試行。
その他の例外・応答不正・タイムアウトはREVIEW/errorとし、自動再試行しません。
SDK内の再試行は無効化して二重再試行を避けています。
max-itemsはチャンク数であり、最大リクエスト試行数は概ね max-items × (1 + max_retries)。
費用上限を直接保証する機能ではありません。提供元の課金上限も設定してください。

## 設定と制限

- 2フォルダ方式のみ。Git参照は新旧を別途エクスポートして使います。
- 改名検知なし。削除＋追加として扱います。実行権限等のメタデータ差分は対象外。
- パーサーなし。行差分と前後context_lines行。複数ファイルの意味解析・呼出し先探索はなし。
- SKILL.mdは自動実行しません。リンク先の自動読込もせず、指定資料を全文送信。
- 関連節検索は未搭載。誤検索による根拠欠落を避ける初期実装です。
- max_payload_charsはstateのJSON文字数のみのローカルガード。質問やプロトコル追加量を含まず、公式トークン上限ではありません。
- 最大バイト数・行数・payload超過は黙って切捨てずblocked/REVIEW。
- 巨大ファイルは同一でもサイズチェックが先なのでREVIEWとなり得ます。
- シンボリックリンク・Windows reparse point（ジャンクション等）は辿りません。
- 秘密情報の自動検出はありません。送信前にドライランのstateと仕様全文を人間が確認。
- SDKログはoff、例外本文は保存しません。カスタムAPI接続先は拒否。
- モデルがjev-latestの場合、同じ入力でも後日同じ出力になる保証はありません。

## トラブル

- Preflight failed: パス、JSON構文、設定名、文字コードを確認。APIは未呼出しです。
- setup_or_internal_error: metadata.fatal_error_type確認。SDK未導入・キー未設定・不正接続先等。
- decode_error: encoding確認。errors=ignore等で隠さない。
- payload_too_large: 短い検証用仕様を人手で作るか、文脈を保った対象縮小。上限増加は公式上限確認後。
- http_401/403: キーと利用権を確認。キーを画面表示しない。
- api_or_schema_error: SDK互換性・ネット接続確認。秘密を含む例外ログを無闇に共有しない。

## 検証と今後

テストは実APIを使わず、差分収集、保存、疑似回答、エラー、認証停止、再試行、中断を検証します。
提供時に実APIへの接続・課金・Windows実機での動作確認は行っていません。
まず架空サンプルで接続確認し、実言語では人間の正解付き差分を用いて見落としを評価してください。
本ツールはSKILL.mdを参照しますが、このユーザー固有の独自言語での有効性は未検証です。

公式情報（2026-09-18確認）:

- https://github.com/typesafe-ai/typesafe-sdk-python
- https://docs.typesafe.ai/sdk/python/usage
- https://docs.typesafe.ai/sdk/python/api/clients/sync

TypeSafe/SDK自体は本ZIPには同梱していません。requirements.txtから取得します。
