import csv
import html
import json
import os
from collections import Counter

FIELDS = ['id', 'path', 'change', 'old_range', 'new_range', 'status', 'bucket', 'reason', 'impact', 'confidence', 'input_hash']

def atomic_json(path, data):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=True, indent=2), encoding='utf-8')
    os.replace(temp, path)

def safe_csv(value):
    value = str(value)
    if value.lstrip().startswith(('=', '+', '-', '@')) or value.startswith(('\t', '\r', '\n')):
        return "'" + value
    return value

def render(directory, report):
    atomic_json(directory / 'report.json', report)
    rows = []
    for item in report['items']:
        row = {k: item.get(k, '') for k in FIELDS}
        answer = item.get('answers', {}).get('impact', {})
        row.update(impact=answer.get('choice', ''), confidence=answer.get('confidence', ''))
        rows.append(row)
    with (directory / 'report.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, FIELDS)
        writer.writeheader()
        writer.writerows({k: safe_csv(v) for k, v in row.items()} for row in rows)
    counts = Counter(i['status'] for i in report['items'])
    summary = '# Comparison summary\n\n' + '\n'.join(f'- {k}: {v}' for k,v in sorted(counts.items()))
    summary += '\n\nLOW disabled. REVIEW, pending and excluded entries require attention.\n'
    summary += f"\nUnchanged files: {report['unchanged_files']}\nExcluded entries (directories counted once): {len(report['excluded'])}\n"
    (directory / 'summary.md').write_text(summary, encoding='utf-8')
    esc = lambda x: html.escape(str(x))
    panels = []
    for item in report['items']:
        state = item.get('state', {})
        panels.append('<article><h2>' + esc(item['id'] + ' · ' + item['path']) + '</h2><p>' +
                      esc(item['bucket'] + ' / ' + item['status'] + ' / ' + item['reason']) + '</p><details><summary>差分・送信状態を確認</summary><pre>' +
                      esc(json.dumps(state, ensure_ascii=False, indent=2)) + '</pre></details></article>')
    text = '<!doctype html><html lang="ja"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jev 比較結果</title><style>body{font:16px/1.7 system-ui;background:#f0f4f7;color:#193047;max-width:1100px;margin:30px auto;padding:20px}article{background:white;padding:20px;margin:15px 0;border-radius:12px}h2{font-size:18px;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere}summary{cursor:pointer}</style><h1>Jev 比較結果</h1><p>LOW無効。REVIEW・未処理・除外一覧を確認してください。レポートにはソースが含まれます。</p><pre>' + esc(summary) + '</pre>' + ''.join(panels)
    text += '<h2>除外一覧</h2><pre>' + esc(json.dumps(report['excluded'], ensure_ascii=False, indent=2)) + '</pre></html>'
    (directory / 'report.html').write_text(text, encoding='utf-8', errors='backslashreplace')
