import argparse
import importlib.metadata
import json
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from . import __version__
from .api import LiveClient, QUESTIONS, classify, evaluate_with_retry
from .core import load_config, load_specs, plan, validate_paths, digest
from .report import atomic_json, render

def execute(args, factory=LiveClient):
    config = load_config(args.config)
    old, new, output = validate_paths(args.old, args.new, args.output, args.skill)
    specs = load_specs(args.skill, config)
    if args.send and args.max_items < 1:
        raise ValueError('--max-items must be positive')
    report = plan(old, new, config, specs)
    try:
        sdk = importlib.metadata.version('typesafe-sdk')
    except importlib.metadata.PackageNotFoundError:
        sdk = None
    report['metadata'] = {'version': __version__, 'sdk_version': sdk,
                          'config': config, 'old': str(old), 'new': str(new),
                          'specifications': specs, 'question_hash': digest(QUESTIONS),
                          'mode': 'live' if args.send else 'dry-run',
                          'created_utc': datetime.now(timezone.utc).isoformat()}
    run = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid.uuid4().hex[:8]
    directory = output / run
    directory.mkdir(parents=True, exist_ok=False)
    for item in report['items']:
        if item['status'] == 'pending':
            item['reason'] = 'not_started' if args.send else 'dry_run_no_network'
    # Complete offline plan exists before any network operation.
    render(directory, report)
    print('Report:', directory)
    print('Items:', len(report['items']), 'LOW: disabled')
    if not args.send:
        print('DRY RUN: no SDK import or network request.')
        return 0
    client = None
    processed, stopped, interrupted = 0, False, False
    current = None
    try:
        client = factory(config)
        with (directory / 'progress.jsonl').open('a', encoding='utf-8') as journal:
            for item in report['items']:
                if item['status'] != 'pending':
                    continue
                if stopped or processed >= args.max_items:
                    item['reason'] = 'auth_stop' if stopped else 'max_items_limit'
                    continue
                current = item
                item.update(status='in_progress', reason='request_started')
                journal.write(json.dumps({'id': item['id'], 'status': 'in_progress'}) + '\n')
                journal.flush()
                answers, error, fatal = evaluate_with_retry(client, item['state'], config['max_retries'])
                processed += 1
                if error:
                    item.update(status='error', reason=error)
                else:
                    bucket, reason = classify(answers)
                    item.update(status='evaluated', bucket=bucket, reason=reason, answers=answers)
                stopped = fatal
                journal.write(json.dumps({k:v for k,v in item.items() if k != 'state'}, ensure_ascii=True) + '\n')
                journal.flush()
                atomic_json(directory / 'report.json', report)
                print(f'{processed}: {item["id"]} {item["bucket"]} {item["status"]}')
                current = None
    except KeyboardInterrupt:
        interrupted = True
        if current is not None:
            current.update(status='error', bucket='REVIEW', reason='interrupted_request_outcome_unknown')
        for item in report['items']:
            if item['status'] == 'pending':
                item['reason'] = 'interrupted_not_started'
    except Exception as exc:
        # Never output SDK error text, since it can contain sensitive request bodies.
        report['metadata']['fatal_error_type'] = type(exc).__name__
        if current is not None:
            current.update(status='error', bucket='REVIEW', reason='internal_error')
        for item in report['items']:
            if item['status'] == 'pending':
                item['reason'] = 'setup_or_internal_error'
    finally:
        if client is not None:
            report['metadata']['api_attempts'] = getattr(client, 'attempts', None)
            try:
                client.close()
            except Exception:
                report['metadata']['close_error'] = True
        render(directory, report)
    if interrupted:
        return 130
    incomplete = any(i['status'] != 'evaluated' for i in report['items'])
    return 2 if incomplete or report['metadata'].get('fatal_error_type') else 0

def main(argv=None):
    p = argparse.ArgumentParser(description='Read-only batch comparison. Default: offline dry-run.')
    p.add_argument('--old', required=True)
    p.add_argument('--new', required=True)
    p.add_argument('--skill', required=True, action='append', help='Repeat for explicitly included specification documents')
    p.add_argument('--config')
    p.add_argument('--output', default='results')
    mode = p.add_mutually_exclusive_group()
    mode.add_argument('--send', action='store_true', help='Authorize external transmission of planned source/spec data')
    mode.add_argument('--dry-run', action='store_true')
    p.add_argument('--max-items', type=int, default=10, help='Maximum chunks sent; retries may multiply requests')
    args = p.parse_args(argv)
    try:
        return execute(args)
    except (ValueError, OSError, UnicodeError, LookupError) as exc:
        print('Preflight failed:', type(exc).__name__, '- check paths/config/encoding. No API call.', file=sys.stderr)
        return 1
