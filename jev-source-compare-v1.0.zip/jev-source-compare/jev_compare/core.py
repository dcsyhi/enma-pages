import codecs
import difflib
import fnmatch
import hashlib
import json
import os
import stat
from pathlib import Path

DEFAULTS = {
    'extensions': ['.xxx', '.inc'],
    'exclude': ['.git', '.venv', 'build', 'vendor', 'generated', '__pycache__'],
    'encoding': 'utf-8', 'context_lines': 40,
    'max_file_bytes': 2000000, 'max_file_lines': 12000,
    'max_payload_chars': 24000, 'max_spec_bytes': 1000000,
    'model': 'jev-latest', 'timeout_seconds': 30, 'max_retries': 2,
}

def digest(data):
    if not isinstance(data, bytes):
        data = json.dumps(data, ensure_ascii=True, sort_keys=True).encode()
    return hashlib.sha256(data).hexdigest()

def load_config(path=None):
    given = json.loads(Path(path).read_text(encoding='utf-8-sig')) if path else {}
    if not isinstance(given, dict) or set(given) - set(DEFAULTS):
        raise ValueError('Unknown config fields or non-object config')
    c = dict(DEFAULTS, **given)
    for key in ('extensions', 'exclude'):
        if not isinstance(c[key], list) or not all(isinstance(s, str) and s for s in c[key]):
            raise ValueError('Invalid config: ' + key)
    if not c['extensions'] or any(not s.startswith('.') for s in c['extensions']):
        raise ValueError('Explicit extensions starting with a dot are required')
    for key in ('context_lines', 'max_file_bytes', 'max_file_lines', 'max_payload_chars',
                'max_spec_bytes', 'timeout_seconds', 'max_retries'):
        if type(c[key]) is not int or c[key] < (0 if key == 'max_retries' else 1):
            raise ValueError('Invalid config: ' + key)
    if c['max_retries'] > 5:
        raise ValueError('max_retries must be <= 5')
    if not isinstance(c['model'], str) or not c['model'].strip():
        raise ValueError('model must be nonempty')
    codecs.lookup(c['encoding'])
    return c

def overlap(a, b):
    return a == b or a in b.parents or b in a.parents

def validate_paths(old, new, output, specs):
    old, new, output = (Path(p).resolve() for p in (old, new, output))
    if not old.is_dir() or not new.is_dir() or overlap(old, new):
        raise ValueError('Old/new must be distinct, non-nested directories')
    if overlap(old, output) or overlap(new, output):
        raise ValueError('Output must be separate from input directories')
    for p in specs:
        if not Path(p).is_file():
            raise ValueError('Specification file not found')
    return old, new, output

def linked(path):
    s = path.lstat()
    return stat.S_ISLNK(s.st_mode) or bool(getattr(s, 'st_file_attributes', 0) & 0x400)

def scan(root, config):
    files, excluded, issues = {}, [], []
    def walk(folder):
        try:
            entries = sorted(folder.iterdir())
        except OSError:
            issues.append({'path': folder.relative_to(root).as_posix(), 'reason': 'directory_read_error'})
            return
        for p in entries:
            rel = p.relative_to(root).as_posix()
            try:
                if linked(p):
                    issues.append({'path': rel, 'reason': 'link_not_followed'})
                elif any(fnmatch.fnmatchcase(rel, pat) or fnmatch.fnmatchcase(p.name, pat)
                         for pat in config['exclude']):
                    excluded.append({'path': rel, 'reason': 'exclude_rule'})
                elif p.is_dir():
                    walk(p)
                elif not p.is_file():
                    issues.append({'path': rel, 'reason': 'not_regular_file'})
                elif p.suffix.lower() not in {s.lower() for s in config['extensions']}:
                    excluded.append({'path': rel, 'reason': 'extension'})
                else:
                    files[rel] = p
            except OSError:
                issues.append({'path': rel, 'reason': 'stat_error'})
    walk(root)
    return files, excluded, issues

def read_bounded(path, limit):
    if path is None:
        return b''
    if linked(path):
        raise ValueError('link_not_followed')
    with path.open('rb') as f:
        data = f.read(limit + 1)
    if len(data) > limit:
        raise ValueError('file_too_large')
    return data

def load_specs(paths, config):
    docs = []
    total = 0
    for i, path in enumerate(paths):
        data = read_bounded(Path(path), config['max_spec_bytes'])
        total += len(data)
        if total > config['max_spec_bytes']:
            raise ValueError('Total specification bytes exceed max_spec_bytes')
        text = data.decode('utf-8-sig')
        if not text.strip():
            raise ValueError('Empty specification')
        docs.append({'id': f'spec-{i+1}', 'name': Path(path).name,
                     'sha256': digest(data), 'text': text})
    return docs

def review(path, reason, **extra):
    return dict(path=path, status='blocked', bucket='REVIEW', reason=reason, **extra)

def file_items(rel, old_path, new_path, config, specs):
    kind = 'added' if old_path is None else 'deleted' if new_path is None else 'modified'
    try:
        a = read_bounded(old_path, config['max_file_bytes'])
        b = read_bounded(new_path, config['max_file_bytes'])
        if old_path is not None and new_path is not None and a == b:
            return [], True
        meta = {'change': kind, 'old_sha256': digest(a), 'new_sha256': digest(b),
                'old_exists': old_path is not None, 'new_exists': new_path is not None}
        old = a.decode(config['encoding'])
        new = b.decode(config['encoding'])
        if '\x00' in old or '\x00' in new:
            return [review(rel, 'binary_or_nul', **meta)], False
        al, bl = old.splitlines(keepends=True), new.splitlines(keepends=True)
        if max(len(al), len(bl)) > config['max_file_lines']:
            return [review(rel, 'too_many_lines', **meta)], False
        # Preserve newlines and whitespace; never silently normalize code.
        groups = list(difflib.SequenceMatcher(None, al, bl, autojunk=False)
                      .get_grouped_opcodes(config['context_lines']))
        if not groups:
            return [review(rel, 'existence_or_encoding_only', **meta)], False
        items = []
        for group in groups:
            a0, a1 = group[0][1], group[-1][2]
            b0, b1 = group[0][3], group[-1][4]
            state = {'specifications': specs, 'path': rel, **meta,
                     'old_range': [a0 + 1, a1], 'new_range': [b0 + 1, b1],
                     'old_code': ''.join(al[a0:a1]), 'new_code': ''.join(bl[b0:b1]),
                     'changed_ranges': [dict(old=[i+1,j], new=[k+1,l])
                                        for tag,i,j,k,l in group if tag != 'equal'],
                     'context_is_partial': a0 > 0 or a1 < len(al) or b0 > 0 or b1 < len(bl)}
            state['diff'] = ''.join(difflib.unified_diff(
                al[a0:a1], bl[b0:b1], fromfile='old (excerpt)', tofile='new (excerpt)',
                n=config['context_lines']))
            item = dict(path=rel, **meta, old_range=state['old_range'], new_range=state['new_range'],
                        state=state, status='pending', bucket='REVIEW', reason='not_evaluated')
            item['payload_chars'] = len(json.dumps(state, ensure_ascii=False))
            if item['payload_chars'] > config['max_payload_chars']:
                item.update(status='blocked', reason='payload_too_large')
            items.append(item)
        return items, False
    except UnicodeError:
        return [review(rel, 'decode_error')], False
    except OSError:
        return [review(rel, 'read_error')], False
    except ValueError as exc:
        return [review(rel, str(exc))], False

def plan(old, new, config, specs):
    af, ax, ai = scan(old, config)
    bf, bx, bi = scan(new, config)
    items = [review(x['path'], x['reason'], side=side)
             for side, issues in [('old', ai), ('new', bi)] for x in issues]
    unchanged = 0
    for rel in sorted(af.keys() | bf.keys()):
        new_items, equal = file_items(rel, af.get(rel), bf.get(rel), config, specs)
        items.extend(new_items)
        unchanged += int(equal)
    for n, item in enumerate(items, 1):
        item['id'] = f'change-{n:06d}'
        item['input_hash'] = digest({'item': item, 'config': config, 'specs': specs})
    return {'items': items, 'unchanged_files': unchanged,
            'old_target_files': len(af), 'new_target_files': len(bf),
            'excluded': [{'side': side, **x} for side, entries in [('old',ax),('new',bx)] for x in entries]}
