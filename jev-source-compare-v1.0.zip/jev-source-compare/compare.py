#!/usr/bin/env python3
"""Read-only source comparison. Offline by default; see README.md."""
from jev_compare.cli import main

if __name__ == '__main__':
    raise SystemExit(main())
